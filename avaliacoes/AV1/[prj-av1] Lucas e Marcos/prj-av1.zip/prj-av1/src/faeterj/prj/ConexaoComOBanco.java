package faeterj.prj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoComOBanco {

	private ConexaoComOBanco() {
	}

	public static Connection getConnection() throws SQLException, ClassNotFoundException {

		Class.forName("org.postgresql.Driver");
		Connection conexao = DriverManager.getConnection("jdbc:postgresql://134.209.243.185/vavatur", "vavatur",
				"gGgLqu");
		return conexao;

	}
}
