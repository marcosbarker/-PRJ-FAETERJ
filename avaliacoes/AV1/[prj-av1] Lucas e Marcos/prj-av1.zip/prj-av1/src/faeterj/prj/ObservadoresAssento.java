package faeterj.prj;

public interface ObservadoresAssento {
	void oAssentoSelecionadoMudou(int assento);
	
}
