package faeterj.prj;


import java.sql.SQLException;

public class Principal {

	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		TelaInicial t1 = new TelaInicial();
		t1.exibir();
		
	}
	
}
