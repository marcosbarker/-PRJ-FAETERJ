package faeterj.prj;

public enum Situacao {
	LIVRE, OCUPADO, SELECIONADO
}
