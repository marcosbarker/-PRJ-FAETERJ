package faeterj.prj;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


public class TelaAssento extends JFrame{
	private JPanel contentPane;
	private List<String> assentos = new ArrayList<String>();
	private Integer assentoSelecionado = null;
	private List<JButton> botoes = new ArrayList<>();
	
	static final String LISTAR_ASSENTO = "Select assento from bilhete";
	static final String ATT_ASSENTO = "Update bilhete SET assento = ";
	
	
	
private List<ObservadoresAssento> listeners = new ArrayList<>(); 
	
	public void addListener(ObservadoresAssento listener) {
		this.listeners.add(listener);
	}
	
	public void removeListener(ObservadoresAssento listener) {
		this.listeners.remove(listener);
	}
	
	public Integer getAssentoSelecionado() {
		return this.assentoSelecionado;
	}
	
	private ActionListener aoClicarNosBotoesDeAssento = (e) -> {
		if (this.assentoSelecionado != null) {
			this.setAssento(this.assentoSelecionado, Situacao.LIVRE);
		}
		this.assentoSelecionado = botoes.indexOf(e.getSource()) + 1;
		this.setAssento(this.assentoSelecionado, Situacao.SELECIONADO);
		
		
		for (ObservadoresAssento listener: this.listeners) {
			listener.oAssentoSelecionadoMudou(this.assentoSelecionado);
		}
	};

	public void exibir() {
		setVisible(true);
	}

	public void BD(String id) throws SQLException, ClassNotFoundException {
		Connection conexao = ConexaoComOBanco.getConnection();

		PreparedStatement cmd = conexao.prepareStatement(LISTAR_ASSENTO + " where id_linha = '" + id + "'");
		cmd.execute();
		ResultSet rs = cmd.getResultSet();
		while (rs.next()) {
			if(rs.getString(1) != null) {
				
				assentos.add(rs.getString(1)); 
			}
		
		};

	}
	
	public void BDAssento(String cod) throws SQLException, ClassNotFoundException {
		Connection conexao = ConexaoComOBanco.getConnection();

		PreparedStatement cmd = conexao.prepareStatement(ATT_ASSENTO + "'" + getAssentoSelecionado() + "',assento_marcado_em = '" + LocalDateTime.now() + "' where codigo = '" + cod + "'");
		cmd.execute();
		
		

	}

	public TelaAssento(String id, String codigo) throws ClassNotFoundException, SQLException {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 700);
		setSize(800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(138,43,226));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		BD(id);
		
		
		
		
		
		
		int j = 0;
		int k = 0;
		for (int i = 0; i < 24; i++) {
			JButton b = new JButton("" + (i + 1));
			botoes.add(b);
			if(i % 2 != 0) {
			b.setBounds(300, (k += 30), 100, 30);
			}else {
				b.setBounds(400, (j += 30), 100, 30);
			}
			b.addActionListener(this.aoClicarNosBotoesDeAssento);
			for (String a : assentos) {
				if((i + 1) == Integer.parseInt(a)) {
					setAssento(i + 1, Situacao.OCUPADO);
					break;
				
				}else {
					setAssento(i + 1, Situacao.LIVRE);
				}
			}
			contentPane.add(b);
			
			
		}		
		
	
		JButton btn = new JButton("Próximo");
		btn.setForeground(new Color(255, 255, 255));
		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if(getAssentoSelecionado() == null) {
						JOptionPane.showMessageDialog(null, "Selecione um lugar");
					}else {
						BDAssento(codigo);
						JOptionPane.showMessageDialog(null, "Checking realizado com sucesso!");
						setVisible(false);
						TelaInicial ti = new TelaInicial();
						ti.exibir();
					}
					
				} catch (ClassNotFoundException | SQLException e1) {
					JOptionPane.showMessageDialog(null, "Não foi possível efetuar o Checking");
				}
			}
		});

		btn.setBounds(300, 450, 200, 23);
		btn.setBackground(new Color(75,0,130));
		contentPane.add(btn);
		
		
		
		
	

	}
	public void setAssento(int assento, Situacao situacao) {
		JButton b = botoes.get(assento - 1);
		if (situacao == Situacao.OCUPADO) {
			b.setBackground(Color.DARK_GRAY);
			b.setEnabled(false);
		} else if (situacao == Situacao.LIVRE) {
			b.setBackground(Color.GREEN);
			b.setEnabled(true);
		} else if (situacao == Situacao.SELECIONADO) {
			b.setBackground(Color.RED);
		}
	}
}
