package faeterj.prj;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaAtt extends JFrame{
	private JPanel contentPane;
	private JTextField nome;
	private JTextField cpf;
	static final String ATT = "Update passageiro SET nome = ";

	public void exibir() {
		setVisible(true);
	}

	public void BD(String nome, String cpf, String id) throws SQLException, ClassNotFoundException {
		Connection conexao = ConexaoComOBanco.getConnection();

		PreparedStatement cmd = conexao.prepareStatement(ATT + "'" + nome + "',cpf = '" + cpf + "' where id = '" + id + "'");
		cmd.execute();
		

	}
	
	public TelaAtt(String nome1, String cpf1, String id, String cod) {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(138,43,226));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel info1 = new JLabel("Atualize seus dados");
		info1.setBounds(300, 50, 600, 60);
		info1.setForeground(new Color(255, 255, 255));
		info1.setFont(new Font("San-Serif", Font.PLAIN, 20));
		contentPane.add(info1);

		JButton btn = new JButton("Salvar alterações");
		btn.setForeground(new Color(255, 255, 255));
		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					BD(nome.getText(), cpf.getText(), id);
					JOptionPane.showMessageDialog(null, "Alterações feitas!");
					setVisible(false);
					TelaInformacoes ti = new TelaInformacoes(cod);
					ti.exibir();
					
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		btn.setBounds(295, 430, 200, 23);
		btn.setBackground(new Color(138,43,226));
		contentPane.add(btn);
		
		
		JButton btnv = new JButton("Voltar");
		btnv.setForeground(new Color(255, 255, 255));
		btnv.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					setVisible(false);
					TelaInformacoes ti = new TelaInformacoes(cod);
					ti.exibir();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		btnv.setBounds(295, 460, 200, 23);
		btnv.setBackground(new Color(138,43,226));
		contentPane.add(btnv);

		nome = new JTextField();
		nome.setBounds(300, 200, 191, 40);
		nome.setText(nome1);
		contentPane.add(nome);
		nome.setColumns(10);
		
		cpf = new JTextField();
		cpf.setBounds(300, 150, 191, 40);
		cpf.setText(cpf1);
		contentPane.add(cpf);
		cpf.setColumns(10);
		
		JPanel card = new JPanel();
		card.setBackground(new Color(75,0,130));
		card.setBounds(250, 30, 300, 500);
		card.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255)));
		contentPane.add(card);
		
		

	}

}
