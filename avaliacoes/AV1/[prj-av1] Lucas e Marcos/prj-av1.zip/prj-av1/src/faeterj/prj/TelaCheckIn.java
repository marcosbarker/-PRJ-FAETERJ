package faeterj.prj;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaCheckIn extends JFrame {
	private JPanel contentPane;
	private JTextField codTicket;
	static final String LISTAR_ALUNOS = "select codigo from bilhete";

	public void exibir() {
		setVisible(true);
	}

	public String BD(String ticket) throws SQLException, ClassNotFoundException {
		String cod = "";
		Connection conexao = ConexaoComOBanco.getConnection();

		PreparedStatement cmd = conexao.prepareStatement(LISTAR_ALUNOS + " where codigo = '" + ticket + "'");
		cmd.execute();
		ResultSet rs = cmd.getResultSet();
		while (rs.next()) {
			cod = rs.getString(1);
		}
		;
		return cod;

	}

	public TelaCheckIn() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(75,0,130));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JPanel box = new JPanel();
		box.setBackground(new Color(0, 0, 0, 100));
		box.setSize(300, 600);
		contentPane.add(box);
		
		JLabel info1 = new JLabel("Código: xxxxxx");
		info1.setBounds(100, 150, 600, 60);
		info1.setForeground(new Color(255, 255, 255));
		info1.setFont(new Font("San-Serif", Font.PLAIN, 12));
		contentPane.add(info1);

		JPanel card = new JPanel();
		card.setBackground(new Color(75,0,130));
		card.setBounds(50, 150, 200, 300);
		contentPane.add(card);
		
		JPanel contentPane1 = new JPanel();
		contentPane1.setBackground(new Color(255, 255, 255));
		contentPane1.setSize(300, 600);
		contentPane.add(contentPane1);
		
		
		
		
		JLabel info = new JLabel("Coloque o código do seu bilhete");
		info.setBounds(400, 150, 600, 60);
		info.setForeground(new Color(255, 255, 255));
		info.setFont(new Font("San-Serif", Font.PLAIN, 20));
		contentPane.add(info);


		JButton btn = new JButton("Próximo");
		btn.setForeground(new Color(255, 255, 255));
		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String cod = BD(codTicket.getText());
					if ( cod == "") {
						JOptionPane.showMessageDialog(null, "O código " + codTicket.getText() + " não existe");
						setVisible(false);
						TelaInicial ti = new TelaInicial();
						ti.exibir();
						
					} else {
						setVisible(false); 
						TelaInformacoes ti = new TelaInformacoes(cod);
						ti.exibir();	
					}
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		btn.setBounds(550, 480, 200, 50);
		btn.setBackground(new Color(138,43,226));
		contentPane.add(btn);

		codTicket = new JTextField();
		codTicket.setBounds(460, 250, 191, 40);
		contentPane.add(codTicket);
		codTicket.setColumns(10);

	}
}
