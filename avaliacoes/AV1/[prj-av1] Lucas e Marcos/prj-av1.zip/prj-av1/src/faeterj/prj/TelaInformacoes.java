package faeterj.prj;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class TelaInformacoes extends JFrame {
	private JPanel contentPane;
	private List<String> l1 = new ArrayList<String>();
	static final String LISTAR = "Select l.origem, l.destino, l.hora_embarque, l.hora_partida, p.nome, p.cpf, b.id_linha, b.codigo, p.id from linha as l inner join bilhete as b on l.id = b.id_linha inner join passageiro as p on p.id = b.id_passageiro";

	public void exibir() {
		setVisible(true);
	}

	public void BD(String ticket) throws SQLException, ClassNotFoundException {
		Connection conexao = ConexaoComOBanco.getConnection();

		PreparedStatement cmd = conexao.prepareStatement(LISTAR + " where codigo = '" + ticket + "'");
		cmd.execute();
		ResultSet rs = cmd.getResultSet();
		while (rs.next()) {
			l1.add(rs.getString(1));
			l1.add(rs.getString(2));
			l1.add(rs.getString(3));
			l1.add(rs.getString(4));
			l1.add(rs.getString(5));
			l1.add(rs.getString(6));
			l1.add(rs.getString(7));
			l1.add(rs.getString(8));
			l1.add(rs.getString(9));

		}
		;

	}
	

	public TelaInformacoes(String cod) throws ClassNotFoundException, SQLException {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 400);
		setSize(800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(75,0,130));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		BD(cod);

		JLabel info = new JLabel("Origem: " + l1.get(0));
		info.setForeground(new Color(138,43,226));
		contentPane.add(info);

		JLabel info1 = new JLabel("Destino: " + l1.get(1));
		info1.setForeground(new Color(138,43,226));
		contentPane.add(info1);

		JLabel info2 = new JLabel("Hora do Embarque: " + l1.get(2));
		info2.setForeground(new Color(138,43,226));
		contentPane.add(info2);

		JLabel info3 = new JLabel("Hora da Partida: " + l1.get(3));
		info3.setForeground(new Color(138,43,226));
		contentPane.add(info3);

		JLabel info4 = new JLabel("Nome: " + l1.get(4));
		info4.setForeground(new Color(138,43,226));
		contentPane.add(info4);

		JLabel info5 = new JLabel("Cpf: " + l1.get(5));
		info5.setForeground(new Color(138,43,226));
		contentPane.add(info5);

		DateTimeFormatter dtf5 = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm");
		JLabel info6 = new JLabel("Horário Atual: " + dtf5.format(LocalDateTime.now()));
		info6.setForeground(new Color(138,43,226));
		contentPane.add(info6);

		info.setBounds(280, 40, 210, 20);
		info1.setBounds(280, 80, 210, 20);
		info2.setBounds(280, 120, 210, 20);
		info3.setBounds(280, 160, 210, 20);
		info4.setBounds(280, 200, 210, 20);
		info5.setBounds(280, 240, 210, 20);
		info6.setBounds(280, 280, 400, 20);

		JButton btn = new JButton("Próximo");
		btn.setForeground(new Color(255, 255, 255));
		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println(l1.get(7));
				try {
					TelaAssento ta = new TelaAssento(l1.get(6), l1.get(7));
					setVisible(false);
					ta.exibir();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		btn.setBounds(295, 400, 200, 23);
		btn.setBackground(new Color(138,43,226));
		contentPane.add(btn);

		JButton btn_att = new JButton("Atualizar dados pessoais");
		btn_att.setForeground(new Color(255, 255, 255));
		btn_att.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				TelaAtt ta = new TelaAtt(l1.get(4), l1.get(5), l1.get(8), l1.get(7));
				setVisible(false);
				ta.exibir();
			}
		});

		btn_att.setBounds(280, 440, 230, 23);
		btn_att.setBackground(new Color(138,43,226));
		contentPane.add(btn_att);

		JPanel card = new JPanel();
		card.setBackground(new Color(255, 255, 255));
		card.setBounds(250, 30, 300, 500);
		card.setBorder(BorderFactory.createLineBorder(new Color(138,43,226)));
		contentPane.add(card);

		

	}
}
