package faeterj.prj;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class TelaInicial extends JFrame {
	private JPanel contentPane;
	private JPanel contentPane1;
	

	public void exibir() {
		setVisible(true);
	}

	public TelaInicial() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(800, 600);
		contentPane = new JPanel();
		contentPane.setSize(800, 600);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(75,0,130));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel title = new JLabel("VAVATUR");
		title.setBounds(220, 80, 600, 60);
		title.setForeground(new Color(138,43,226));
		title.setFont(new Font("San-Serif", Font.PLAIN, 70));
		contentPane.add(title);
		
		JLabel info = new JLabel("Clique aqui para realizar se Checking");
		info.setBounds(220, 300, 600, 60);
		info.setForeground(new Color(255, 255, 255));
		info.setFont(new Font("San-Serif", Font.PLAIN, 20));
		contentPane.add(info);

		
		contentPane1 = new JPanel();
		contentPane1.setBackground(new Color(255, 255, 255));
		contentPane1.setSize(800, 200);
		contentPane.add(contentPane1);
		
		JButton btn = new JButton("Realizar Checking");
		btn.setForeground(new Color(255, 255, 255));
		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				TelaCheckIn tc = new TelaCheckIn();
				tc.exibir();
			}
		});
		btn.setBounds(300, 400, 200, 60);
		btn.setBackground(new Color(138,43,226));
		contentPane.add(btn);
	}
}
