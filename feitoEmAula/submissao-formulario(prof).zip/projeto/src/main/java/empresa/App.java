package empresa;

import static spark.Spark.*;
import static spark.debug.DebugScreen.*;

public class App {
    
	public static void main( String[] args ) {
		enableDebugScreen();
		port(8080);
        get("/", Views.paginaInicial);
        post("/submissao", Views.submissao);
    }
}
