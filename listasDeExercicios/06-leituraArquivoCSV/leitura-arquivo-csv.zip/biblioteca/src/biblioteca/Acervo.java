package biblioteca;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Acervo {

	private ArrayList<Livro> livros;
	
	public Acervo() {
		 livros = new ArrayList<>();
	}
	
	public List<Livro> getLivros() {
		return Collections.unmodifiableList(this.livros);
	}
	
	public void adicionarLivro(Livro livro) {
		this.livros.add(livro);
	}
	
	public void removerLivro(Livro livro) {
		this.livros.remove(livro);
	}
	
	public void salvar(String nomeArquivo) throws IOException {
//		Escrita em bytes
//		FileOutputStream out = new FileOutputStream(nomeArquivo);
//		out.write("Jose da silva".getBytes());
//		out.close();
		
//		Escrita em caracter
		FileWriter fw = new FileWriter(nomeArquivo);		
		PrintWriter pw = new PrintWriter(fw, true);
		for (Livro l: this.livros) {
			pw.printf("%s,%s,%s,%s\n", l.getISBN(), l.getTitulo(), l.getAutor(), l.getDataPublicacao().toString());
		}
		pw.close();
	}
	
	public void carregar(String nomeArquivo) throws IOException {
//		Leitura em bytes
//		FileInputStream in = new FileInputStream(nomeArquivo);
//		byte[] dados = in.readAllBytes();
//		String s = new String(dados);
//		System.out.println("s: " + s);
//		in.close();	

//		Leitura em caracter e linha a linha
		BufferedReader br = new BufferedReader(new FileReader(nomeArquivo));
		while (br.ready()) {
			String linha = br.readLine();
			System.out.println("Linha: " + linha);
		}
		br.close();
	}	
}