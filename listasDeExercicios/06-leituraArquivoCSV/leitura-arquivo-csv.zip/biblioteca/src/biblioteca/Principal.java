package biblioteca;

import java.io.IOException;
import java.time.LocalDate;

public class Principal {

	public static void main(String[] args) {
		Acervo acervo = new Acervo();
		
		Livro l = new Livro();
		l.setAutor("Jose Saramago");
		l.setTitulo("Cem anos de solidão");
		l.setISBN("1234567890-987");
		l.setDataPublicacao(LocalDate.of(1980, 6, 15));
		
		acervo.adicionarLivro(l);
		
		try {
			acervo.salvar("acervo.txt");
		} catch (IOException e) {
			System.out.println("paciencia");
			e.printStackTrace();
		}
		
	}
	
}
