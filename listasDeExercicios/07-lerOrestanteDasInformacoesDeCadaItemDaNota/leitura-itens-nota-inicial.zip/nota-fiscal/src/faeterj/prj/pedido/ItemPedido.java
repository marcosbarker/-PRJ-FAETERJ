package faeterj.prj.pedido;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class ItemPedido {

	private String codigo;
	private String descricao;	
	private int quantidade;
	private String unidade;
	private String valorUnitario;
	private String valorTotal;
	
	public void carregar(Scanner sc) {
		// inicia com uma descrição vazia
		this.descricao = "";
		String palavra = null;
		// enquanto houver palavras
		while ((palavra = sc.next()) != null) {
			// se for a palavra "(Código:", acabou a descricao
			if (palavra.equals("(Código:")) {
				break;
			} else {
				// concatena a palavra na descricao
				this.descricao += " " + palavra;
			}
		}
		this.codigo = sc.next();
		sc.nextLine(); // avança até o fim da linha atual, ignorando
		
		sc.nextLine(); // avança a 2a linha, ignorando-a
		sc.nextLine(); // avança a 3a linha, ignorando-a		
	}
	
	@Override
	public String toString() {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		PrintWriter out = new PrintWriter(buffer);
		out.printf("%s\t%s", this.codigo, this.descricao);
		out.close();
		return buffer.toString();
	}
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public String getUnidade() {
		return unidade;
	}
	public void setUnidade(String unidade) {
		this.unidade = unidade;
	}
	public String getValorUnitario() {
		return valorUnitario;
	}
	public void setValorUnitario(String valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	public String getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}	
}
